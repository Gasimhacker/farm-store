import 'package:gasim_farm/constants.dart';
import 'package:flutter/material.dart';

//This function is used to change the color of the selected/unselected button inside the store page as well as selected/unselected text.
// void changeColor(Type selectedType) {
//   //any constant that starts with (K) is initialized in (constant.dart)file.
//   if (selectedType == Type.fruit) {
//     KFruitButtonColor = Colors.orange;
//     KFruitTextColor = Colors.white;
//     KVegetablesButtonColor = Colors.white;
//     KVegetablesTextColor = Colors.grey;
//   } else {
//     KVegetablesButtonColor = Colors.orange;
//     KVegetablesTextColor = Colors.white;
//     KFruitButtonColor = Colors.white;
//     KFruitTextColor = Colors.grey;
//   }
// }
