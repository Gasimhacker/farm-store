package com.example.gasim_farm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
